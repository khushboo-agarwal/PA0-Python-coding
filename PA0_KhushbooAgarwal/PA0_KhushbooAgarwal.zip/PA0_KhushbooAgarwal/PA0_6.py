num = int(input("Enter a 4 digit number: "))

A = []

diff1=0
difference = []
difference.append(num)
length = 0
def Persistence_Difference(num):
    M = m = 0
    number = str(num)

    for i in range(0,len(number)):
        n=int(number[i])
        A.append(n)
    A.sort()
    for i in range(0, len(number)):
        m = m+(A[i]*(pow(10,(len(number)-(i+1)))))
        M = M+(A[(len(number)-(i+1))]*(pow(10,(len(number)-(i+1)))))
    diff1 = M-m
    print(diff1)
    difference.append(diff1)
    length = len(difference)
Persistence_Difference(num)

flag = 0
while(flag!=1):
    Persistence_Difference(num)
    for i in range(0,len(difference), 1):
        if(diff1 == difference[i]):
            flag = 1

print diff1
print(difference)






